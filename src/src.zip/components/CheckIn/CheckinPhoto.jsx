import React from 'react';
import { useLocation } from 'react-router-dom';

const CheckinPhoto = () => {
  const location = useLocation();
  const { store, branch } = location.state || {};

  return (
    <div className="checkin-success-container">
      <h1>เช็คอินสำเร็จ!</h1>
      <p>ร้าน: {store}</p>
      <p>สาขา: {branch}</p>
    </div>
  );
};

export default CheckinPhoto;
