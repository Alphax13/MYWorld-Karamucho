import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Checkin from "../components/CheckIn/Checkin";
import CheckinPhoto from "../components/CheckIn/CheckinPhoto";

const CheckIn = () => {
  return (
    <Router>
      <div className="min-h-screen m-0">
        <Checkin />
        <Routes>
          <Route path="/checkin-success" element={<CheckinPhoto />} />
        </Routes>
      </div>
    </Router>
  );
};

export default CheckIn;
